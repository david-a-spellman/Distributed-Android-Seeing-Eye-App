<!--
 * @Author: shen fan
 * @Date: 2021-08-31 03:03:52
 * @LastEditors: shen fan
 * @LastEditTime: 2022-04-26 21:58:43
 * @Description:       
 * @FilePath: /mtcnn_tensorflowlit model/README.md
-->
# for server
 python test/test_mtcnn.py

# for client 
python client.py