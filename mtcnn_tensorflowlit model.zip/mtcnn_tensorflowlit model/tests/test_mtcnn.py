'''
Author: shen fan
Date: 2021-08-31 06:03:52
LastEditors: shen fan
LastEditTime: 2022-04-15 16:25:25
Description:       
FilePath: /mtcnn-tflite-master/tests/test_mtcnn.py
'''
import unittest
import cv2

from mtcnn_tflite.exceptions import InvalidImage
from mtcnn_tflite.MTCNN import MTCNN
import base64
mtcnn = None
import numpy as np

import datetime
from xmlrpc.server import SimpleXMLRPCServer
import xmlrpc.client

def send(image):
    image_encode = bytes(image, 'ascii')
    print(type(image_encode))
    im_bytes = base64.decodebytes(image_encode)
    print(type(im_bytes))
    im_bytes = np.frombuffer(im_bytes, dtype=np.uint8)  
    print(im_bytes.shape)
    im_bytes = cv2.imdecode(im_bytes, flags=1)
    print(im_bytes.shape)
    name = '1.png'
    cv2.imwrite(name, im_bytes)
    global mtcnn
    mtcnn = MTCNN()

    
        
    image = cv2.cvtColor(cv2.imread(name), cv2.COLOR_BGR2RGB)
    result = mtcnn.detect_faces(image)  # type: list
    bounding_box = result[0]['box']
    keypoints = result[0]['keypoints']

    cv2.rectangle(image,
                (bounding_box[0], bounding_box[1]),
                (bounding_box[0]+bounding_box[2], bounding_box[1] + bounding_box[3]),
                (0,155,255),
                2)

    cv2.circle(image,(keypoints['left_eye']), 2, (0,155,255), 2)
    cv2.circle(image,(keypoints['right_eye']), 2, (0,155,255), 2)
    cv2.circle(image,(keypoints['nose']), 2, (0,155,255), 2)
    cv2.circle(image,(keypoints['mouth_left']), 2, (0,155,255), 2)
    cv2.circle(image,(keypoints['mouth_right']), 2, (0,155,255), 2)

    cv2.imwrite("ivan_drawn.png", cv2.cvtColor(image, cv2.COLOR_RGB2BGR))
    print(image.shape)

    image = open('ivan_drawn.png', "rb") 
    image_read = image.read()
    #print(image)
    image_en = base64.b64encode(image_read).decode('ascii')
    return image_en

# if __name__ == '__main__':
#     unittest.main()
server = SimpleXMLRPCServer(("localhost", 8000))
print("Listening on port 8000...")
server.register_function(send, "send")
server.serve_forever()