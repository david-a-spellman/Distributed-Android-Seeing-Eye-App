'''
Author: shen fan
Date: 2022-04-26 21:56:50
LastEditors: shen fan
LastEditTime: 2022-04-26 21:56:51
Description:       
FilePath: /mtcnn_tensorflowlit model/tests/client.py
'''
import base64
import xmlrpc.client
import datetime
import cv2
import numpy as np
proxy = xmlrpc.client.ServerProxy("http://localhost:8000/")
image_path = "mtcnn_tflite/data/ivan.png"
image = open(image_path, "rb") 
image_read = image.read()
image_encode = base64.b64encode(image_read).decode('ASCII')
ima = proxy.send(image_encode)
print(type(ima))
ima = bytes(ima,'ascii')
im_b = base64.decodebytes(ima)
print(type(im_b))
im_b = np.frombuffer(im_b, dtype=np.uint8)  
print(im_b.shape)
im_by = cv2.imdecode(im_b,flags =1)
print(im_by)
cv2.imwrite('result.png',im_by)
