'''
Author: shen fan
Date: 2021-08-31 03:03:52
LastEditors: shen fan
LastEditTime: 2022-04-26 21:55:25
Description:       
FilePath: /mtcnn_tensorflowlit model/mtcnn_tflite/exceptions/__init__.py
'''

from mtcnn_tflite.exceptions.invalid_image import InvalidImage
