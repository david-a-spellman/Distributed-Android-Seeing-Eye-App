'''
Author: shen fan
Date: 2021-08-31 03:03:52
LastEditors: shen fan
LastEditTime: 2022-04-26 21:55:30
Description:       
FilePath: /mtcnn_tensorflowlit model/mtcnn_tflite/exceptions/invalid_image.py
'''

__author__ = "Iván de Paz Centeno"

class InvalidImage(Exception):
    pass
